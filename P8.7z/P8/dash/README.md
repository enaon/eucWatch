# EUC Dash

This is the app for the EUC Dash.

## Usage

Swipe down when active to switch between simple and advanced interfaces.

In advanced:
- Long tap the speed indicator to change between MPH and KPH.
- Short tap the battery indicator to switch between voltage, percentage, and a battery bar.
- Long tap on the battery indicator when in voltage mode to change the voltage.
- Swipe left to see settings.

This file provides support for the [Gardetbridge](https://f-droid.org/en/packages/nodomain.freeyourgadget.gadgetbridge/) android app. 
It also uses the weather [companion app](https://codeberg.org/Freeyourgadget/Gadgetbridge/wiki/Weather) to display current weather information.

It  uses the settings face(swipe up-BT) to enable/disable the service. 

###### What works

Notifications, call handling(answer/ignore), weather.

###### todo

synchronize notififation on dismiss. 

add support for OsmAnd gps instructions. 


##### This is a simple Hello app to be used as a starting template.

See the comments inside hello.js file for more info.

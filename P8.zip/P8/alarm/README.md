##### How to use:

Access the alarms face by touching the minutes field on main clock face. When no alarms are enabled, the minutes field color will be raf, when one or more alarms are enabled, the color will me blue, and when one is active, it will be yellow until acknowledged.

The main alarms face shows the tree alarms, their set time and their status. Gray is disabled, blue is enabled. 
**Status can be switched by taping on the alarm field.** 

**To set an alarm, long hold on it or swipe left on it.** 

This will get you to set alarm face, where you can swipe up/down on hours, 10nths of minutes or minutes. You can also set the alarm to auto repeat.

The alarms can duplicate as timers. 
While on set face, long hold anywhere on the screen. The current time will be set. If the current time is 10:50, two swipes up on the tenths of minutes will get the time to 11:10, 20 minutes from now. 

**Alarms are acknowledged by a long press on the minutes field on the clock face, or by a swipe left on the active alarm on the alarms face, when the alarm in active(buzzing).**

To return to the clock face, do a swipe right. 


##### todo:

make alarms survive reboots

enable snoozing

enable days selection on repeat

Synchronize alarms with Gadgetbridge

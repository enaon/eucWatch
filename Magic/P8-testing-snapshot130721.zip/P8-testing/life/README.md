##### Conway's Game of Life cellular automata

Ported by MightyWither
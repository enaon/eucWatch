This is a core file that handles the accelerometer( two types), the touch screen(tree types), the watches's settings, the BT config, the faces and the themes(todo). 

It loads/saves(on restart) custom settings from/to setting.json file. 


Use the Settings app face to change settings, Bt configuration and themes. 

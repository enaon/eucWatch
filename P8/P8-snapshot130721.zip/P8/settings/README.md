##### How to enter settings face:

Using a swipe up from bottom down from any other face will get you to settings face. To exit, a swipe right/down will get you back to the previus face.  


